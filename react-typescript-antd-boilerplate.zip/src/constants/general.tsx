export const GITHUB_LINK = 'https://github.com/LucasBassetti/react-typescript-antd-boilerplate';

interface IReducerStates {
  list: IItem[];
  router: any;
}

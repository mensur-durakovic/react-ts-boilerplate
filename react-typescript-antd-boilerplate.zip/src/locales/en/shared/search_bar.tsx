export default {
  currentLocation: 'Current Location',
  findATable: 'Find a Table',
  loading: 'Loading...',
  location: 'Location',
  people: 'People',
  person: 'Person'
};

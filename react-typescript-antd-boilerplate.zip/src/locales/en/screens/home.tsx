export default {
  githubLink: 'Github Link',
  loading: 'Loading...',
  title: 'Example'
};

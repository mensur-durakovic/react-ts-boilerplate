export default {
  title: 'React TypeScript Ant Design Boilerplate'
};

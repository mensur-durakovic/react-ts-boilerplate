import React from 'react';
type Props = {};

const Reports: React.FC<Props> = () => {
  return <div className="reports">Reports</div>;
};

export default Reports;

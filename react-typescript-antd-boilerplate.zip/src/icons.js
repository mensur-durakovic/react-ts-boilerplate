export { default as LoadingOutline } from '@ant-design/icons/lib/outline/LoadingOutline';
export { default as CloseOutline } from '@ant-design/icons/lib/outline/CloseOutline';